'use client'

import { useState } from 'react'
import { Post } from '@/lib/posts'
import PostCard from './PostCard'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface PostListProps {
  posts: Post[]
  postsPerPage: number
}

export default function PostList({ posts, postsPerPage }: PostListProps) {
  const [currentPage, setCurrentPage] = useState(1)
  const totalPages = Math.ceil(posts.length / postsPerPage)
  const start = (currentPage - 1) * postsPerPage
  const currentPosts = posts.slice(start, start + postsPerPage)

  if (posts.length === 0) {
    return <div className="text-center py-12 text-[var(--muted-color)]">暂无文章</div>
  }

  return (
    <div>
      <div className="space-y-4">
        {currentPosts.map((post) => (
          <PostCard key={post.slug} post={post} />
        ))}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-8">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-2 rounded border border-[var(--border-color)] disabled:opacity-30 hover:border-[var(--primary-color)] transition-colors"
          >
            <ChevronLeft size={16} />
          </button>
          <span className="text-sm text-[var(--muted-color)]">
            {currentPage} / {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-2 rounded border border-[var(--border-color)] disabled:opacity-30 hover:border-[var(--primary-color)] transition-colors"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  )
}
