'use client'

import { useEffect, useState } from 'react'
import { List } from 'lucide-react'

interface TocItem {
  id: string
  text: string
  level: number
}

interface TocProps {
  content: string
}

export default function Toc({ content }: TocProps) {
  const [items, setItems] = useState<TocItem[]>([])
  const [activeId, setActiveId] = useState('')

  useEffect(() => {
    const parser = new DOMParser()
    const doc = parser.parseFromString(content, 'text/html')
    const headings = doc.querySelectorAll('h2, h3, h4')
    const tocItems: TocItem[] = []
    headings.forEach((h, i) => {
      const id = `heading-${i}`
      h.setAttribute('id', id)
      tocItems.push({
        id,
        text: h.textContent || '',
        level: parseInt(h.tagName[1]),
      })
    })
    setItems(tocItems)
  }, [content])

  useEffect(() => {
    const handleScroll = () => {
      const headings = document.querySelectorAll('.markdown-content h2, .markdown-content h3, .markdown-content h4')
      let current = ''
      headings.forEach((h) => {
        const rect = h.getBoundingClientRect()
        if (rect.top < 100) current = h.id
      })
      setActiveId(current)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  if (items.length === 0) return null

  return (
    <div className="p-4 rounded-xl bg-[var(--toc-bg)] border border-[var(--border-color)]">
      <h3 className="font-bold mb-3 flex items-center gap-2 text-sm" style={{ color: 'var(--heading-color)' }}>
        <List size={14} /> 目录
      </h3>
      <ul className="space-y-1.5 text-sm">
        {items.map((item) => (
          <li key={item.id} style={{ paddingLeft: `${(item.level - 2) * 12}px` }}>
            <a
              href={`#${item.id}`}
              className={`block py-0.5 transition-colors ${
                activeId === item.id
                  ? 'text-[var(--primary-color)] font-medium'
                  : 'text-[var(--muted-color)] hover:text-[var(--text-color)]'
              }`}
              onClick={(e) => {
                e.preventDefault()
                document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' })
              }}
            >
              {item.text}
            </a>
          </li>
        ))}
      </ul>
    </div>
  )
}
