'use client'

import { useState, useEffect, useRef } from 'react'
import { Search as SearchIcon, X } from 'lucide-react'
import Link from 'next/link'

interface SearchPost {
  slug: string
  title: string
  excerpt: string
}

interface SearchProps {
  posts: SearchPost[]
}

export default function Search({ posts }: SearchProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchPost[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (query.length >= 2) {
      const lowerQuery = query.toLowerCase()
      setResults(
        posts.filter(
          (post) =>
            post.title.toLowerCase().includes(lowerQuery) ||
            post.excerpt.toLowerCase().includes(lowerQuery)
        )
      )
    } else {
      setResults([])
    }
  }, [query, posts])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        setIsOpen(true)
      }
      if (e.key === 'Escape') setIsOpen(false)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [isOpen])

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="p-2 rounded-lg hover:bg-[var(--border-color)] transition-colors flex items-center gap-2 text-sm text-[var(--muted-color)]"
      >
        <SearchIcon size={16} />
        <span className="hidden lg:inline">搜索</span>
        <kbd className="hidden lg:inline px-1.5 py-0.5 text-xs rounded bg-[var(--border-color)]">Ctrl+K</kbd>
      </button>
    )
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[20vh] bg-black/50" onClick={() => setIsOpen(false)}>
      <div className="w-full max-w-lg mx-4 bg-[var(--secondary-bg)] rounded-xl shadow-2xl border border-[var(--border-color)] overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 p-3 border-b border-[var(--border-color)]">
          <SearchIcon size={18} className="text-[var(--muted-color)]" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索文章..."
            className="flex-1 bg-transparent outline-none text-[var(--text-color)] placeholder:text-[var(--muted-color)]"
          />
          <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-[var(--border-color)] rounded transition-colors">
            <X size={16} className="text-[var(--muted-color)]" />
          </button>
        </div>
        {results.length > 0 && (
          <div className="max-h-80 overflow-y-auto">
            {results.map((post) => (
              <Link
                key={post.slug}
                href={`/posts/${post.slug}/`}
                onClick={() => setIsOpen(false)}
                className="block p-3 hover:bg-[var(--bg-color)] border-b border-[var(--border-color)] last:border-0 transition-colors"
              >
                <div className="font-medium text-[var(--text-color)]">{post.title}</div>
                <div className="text-xs text-[var(--muted-color)] mt-1 line-clamp-1">{post.excerpt}</div>
              </Link>
            ))}
          </div>
        )}
        {query.length >= 2 && results.length === 0 && (
          <div className="p-4 text-center text-sm text-[var(--muted-color)]">未找到相关文章</div>
        )}
      </div>
    </div>
  )
}
