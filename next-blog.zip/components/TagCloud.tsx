import Link from 'next/link'

interface TagCloudProps {
  tags: { name: string; count: number }[]
}

export default function TagCloud({ tags }: TagCloudProps) {
  const maxCount = Math.max(...tags.map((t) => t.count), 1)

  return (
    <div className="flex flex-wrap gap-2">
      {tags.map((tag) => {
        const size = 0.75 + (tag.count / maxCount) * 0.5
        return (
          <Link key={tag.name} href={`/tags/${encodeURIComponent(tag.name)}/`}>
            <span
              className="inline-block px-2 py-1 rounded bg-[var(--bg-color)] text-[var(--muted-color)] hover:text-[var(--primary-color)] hover:bg-[var(--primary-color)]/10 transition-colors"
              style={{ fontSize: `${size}rem` }}
            >
              {tag.name}
            </span>
          </Link>
        )
      })}
    </div>
  )
}
