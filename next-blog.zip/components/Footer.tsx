import { getConfig } from '@/lib/config'
import { Github, Twitter, Mail, Rss, Globe, MessageCircle, BookOpen, Coffee } from 'lucide-react'

const iconMap: Record<string, React.ReactNode> = {
  github: <Github size={16} />,
  twitter: <Twitter size={16} />,
  email: <Mail size={16} />,
  rss: <Rss size={16} />,
  website: <Globe size={16} />,
  telegram: <MessageCircle size={16} />,
  blog: <BookOpen size={16} />,
  weibo: <Coffee size={16} />,
}

export default async function Footer() {
  const config = await getConfig()
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-[var(--border-color)] py-8 mt-auto">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-sm text-[var(--muted-color)]">
            &copy; {config.footer.since}-{currentYear} {config.site.author}
            {config.footer.beian && (
              <span className="ml-2">{config.footer.beian}</span>
            )}
          </div>

          <div className="flex items-center gap-4">
            {config.social.map((item) => (
              <a
                key={item.name}
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[var(--muted-color)] hover:text-[var(--primary-color)] transition-colors"
                title={item.name}
              >
                {iconMap[item.icon] || <Globe size={16} />}
              </a>
            ))}
          </div>

          {config.footer.powered && (
            <div className="text-xs text-[var(--muted-color)]">
              Powered by <span className="text-[var(--primary-color)]">Next.js</span>
            </div>
          )}
        </div>
        {config.footer.custom && (
          <div className="mt-4 text-center text-xs text-[var(--muted-color)]" dangerouslySetInnerHTML={{ __html: config.footer.custom }} />
        )}
      </div>
    </footer>
  )
}
