'use client'

import { Sun, Moon } from 'lucide-react'
import { useTheme } from './ThemeProvider'

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme()

  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-lg hover:bg-[var(--border-color)] transition-colors"
      aria-label="切换主题"
    >
      {theme === 'light' ? (
        <Moon size={18} className="text-[var(--text-color)]" />
      ) : (
        <Sun size={18} className="text-[var(--text-color)]" />
      )}
    </button>
  )
}
