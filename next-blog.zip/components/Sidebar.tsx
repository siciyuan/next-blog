import { getConfig } from '@/lib/config'
import { getAllTags, getAllCategories, getAllPosts } from '@/lib/posts'
import TagCloud from './TagCloud'
import Link from 'next/link'
import { Calendar, FolderOpen, Tag as TagIcon, Clock } from 'lucide-react'

export default async function Sidebar() {
  const config = await getConfig()
  const tags = await getAllTags()
  const categories = await getAllCategories()
  const posts = await getAllPosts()
  const recentPosts = posts.slice(0, 5)

  return (
    <aside className="w-full lg:w-72 shrink-0 space-y-6">
      {/* Profile */}
      <div className="p-5 rounded-xl bg-[var(--secondary-bg)] border border-[var(--border-color)]">
        <div className="flex items-center gap-3 mb-3">
          {config.site.avatar ? (
            <img src={config.site.avatar} alt="avatar" className="w-12 h-12 rounded-full" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-[var(--primary-color)] flex items-center justify-center text-white font-bold text-lg">
              {config.site.author.charAt(0)}
            </div>
          )}
          <div>
            <div className="font-bold" style={{ color: 'var(--heading-color)' }}>{config.site.author}</div>
            <div className="text-xs text-[var(--muted-color)]">{config.site.description}</div>
          </div>
        </div>
        <div className="flex gap-4 text-sm text-[var(--muted-color)]">
          <span className="flex items-center gap-1"><Calendar size={14} /> {posts.length} 文章</span>
          <span className="flex items-center gap-1"><TagIcon size={14} /> {tags.length} 标签</span>
        </div>
      </div>

      {/* Recent Posts */}
      <div className="p-5 rounded-xl bg-[var(--secondary-bg)] border border-[var(--border-color)]">
        <h3 className="font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--heading-color)' }}>
          <Clock size={16} /> 最近文章
        </h3>
        <ul className="space-y-2">
          {recentPosts.map((post) => (
            <li key={post.slug}>
              <Link href={`/posts/${post.slug}/`} className="text-sm text-[var(--text-color)] hover:text-[var(--primary-color)] transition-colors line-clamp-1">
                {post.title}
              </Link>
            </li>
          ))}
        </ul>
      </div>

      {/* Categories */}
      {categories.length > 0 && (
        <div className="p-5 rounded-xl bg-[var(--secondary-bg)] border border-[var(--border-color)]">
          <h3 className="font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--heading-color)' }}>
            <FolderOpen size={16} /> 分类
          </h3>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <Link key={cat.name} href={`/category/${encodeURIComponent(cat.name)}/`}>
                <span className="px-2 py-1 text-xs rounded bg-[var(--bg-color)] text-[var(--muted-color)] hover:text-[var(--primary-color)] hover:bg-[var(--primary-color)]/10 transition-colors cursor-pointer">
                  {cat.name} ({cat.count})
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Tags */}
      {tags.length > 0 && (
        <div className="p-5 rounded-xl bg-[var(--secondary-bg)] border border-[var(--border-color)]">
          <h3 className="font-bold mb-3 flex items-center gap-2" style={{ color: 'var(--heading-color)' }}>
            <TagIcon size={16} /> 标签云
          </h3>
          <TagCloud tags={tags} />
        </div>
      )}
    </aside>
  )
}
