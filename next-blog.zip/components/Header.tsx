import Link from 'next/link'
import { getConfig } from '@/lib/config'
import { getAllPosts } from '@/lib/posts'
import ThemeToggle from './ThemeToggle'
import Search from './Search'
import { Home, Archive, Tag, User, BookOpen } from 'lucide-react'

const iconMap: Record<string, React.ReactNode> = {
  home: <Home size={16} />,
  archive: <Archive size={16} />,
  tag: <Tag size={16} />,
  user: <User size={16} />,
  book: <BookOpen size={16} />,
}

export default async function Header() {
  const config = await getConfig()
  const allPosts = await getAllPosts()
  const searchPosts = allPosts.map((p) => ({ slug: p.slug, title: p.title, excerpt: p.excerpt }))

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-[var(--bg-color)]/80 border-b border-[var(--border-color)]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          <Link href="/" className="flex items-center gap-2">
            {config.site.avatar && (
              <img src={config.site.avatar} alt="avatar" className="w-8 h-8 rounded-full" />
            )}
            <span className="font-bold text-lg" style={{ color: 'var(--heading-color)' }}>
              {config.site.title}
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            {config.nav.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className="flex items-center gap-1.5 text-sm text-[var(--text-color)] hover:text-[var(--primary-color)] transition-colors"
              >
                {item.icon && iconMap[item.icon]}
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {config.search.enable && <Search posts={searchPosts} />}
            <ThemeToggle />
          </div>
        </div>
      </div>
    </header>
  )
}
