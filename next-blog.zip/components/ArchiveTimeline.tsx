import Link from 'next/link'
import { Post } from '@/lib/posts'
import { formatDateShort } from '@/lib/utils'
import { Calendar, FileText } from 'lucide-react'

interface ArchiveData {
  year: string
  months: { month: string; posts: Post[] }[]
}

interface ArchiveTimelineProps {
  data: ArchiveData[]
}

export default function ArchiveTimeline({ data }: ArchiveTimelineProps) {
  return (
    <div className="space-y-8">
      {data.map((yearData) => (
        <div key={yearData.year}>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2" style={{ color: 'var(--heading-color)' }}>
            <Calendar size={20} className="text-[var(--primary-color)]" />
            {yearData.year} 年
          </h2>
          <div className="ml-4 border-l-2 border-[var(--border-color)] pl-6 space-y-6">
            {yearData.months.map((monthData) => (
              <div key={monthData.month}>
                <h3 className="text-sm font-semibold text-[var(--muted-color)] mb-2">
                  {monthData.month} 月 ({monthData.posts.length} 篇)
                </h3>
                <div className="space-y-2">
                  {monthData.posts.map((post) => (
                    <div key={post.slug} className="flex items-start gap-3 group">
                      <span className="text-xs text-[var(--muted-color)] shrink-0 mt-1">
                        {formatDateShort(post.date).slice(5)}
                      </span>
                      <Link
                        href={`/posts/${post.slug}/`}
                        className="text-[var(--text-color)] hover:text-[var(--primary-color)] transition-colors line-clamp-1"
                      >
                        {post.title}
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
