import Link from 'next/link'
import { Post } from '@/lib/posts'
import { formatDate } from '@/lib/utils'
import { Clock, Tag } from 'lucide-react'

interface PostCardProps {
  post: Post
}

export default function PostCard({ post }: PostCardProps) {
  return (
    <article className="group p-5 rounded-xl bg-[var(--secondary-bg)] border border-[var(--border-color)] hover:shadow-lg hover:border-[var(--primary-color)]/30 transition-all duration-300">
      <Link href={`/posts/${post.slug}/`}>
        <h2 className="text-xl font-bold mb-2 group-hover:text-[var(--primary-color)] transition-colors" style={{ color: 'var(--heading-color)' }}>
          {post.title}
        </h2>
      </Link>

      <div className="flex flex-wrap gap-3 text-xs text-[var(--muted-color)] mb-3">
        <span>{formatDate(post.date)}</span>
        <span className="flex items-center gap-1"><Clock size={12} /> {post.readingTime} 分钟</span>
      </div>

      <p className="text-sm text-[var(--text-color)]/80 line-clamp-2 mb-3">{post.excerpt}</p>

      {post.tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {post.tags.map((tag) => (
            <Link key={tag} href={`/tags/${encodeURIComponent(tag)}/`}>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs rounded border border-[var(--border-color)] text-[var(--muted-color)] hover:text-[var(--primary-color)] hover:border-[var(--primary-color)] transition-colors">
                <Tag size={10} /> {tag}
              </span>
            </Link>
          ))}
        </div>
      )}
    </article>
  )
}
