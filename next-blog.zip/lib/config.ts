import yaml from 'js-yaml'
import fs from 'fs'
import path from 'path'

export interface SiteConfig {
  title: string
  subtitle: string
  description: string
  author: string
  language: string
  keywords: string[]
  url: string
  favicon?: string
  avatar?: string
}

export interface NavItem {
  label: string
  path: string
  icon?: string
}

export interface SocialItem {
  name: string
  url: string
  icon: string
}

export interface ThemeConfig {
  scheme: 'light' | 'dark' | 'auto'
  primaryColor: string
  accentColor: string
  showToc: boolean
  showBackToTop: boolean
  showReadingProgress: boolean
  postsPerPage: number
  codeTheme: string
}

export interface FooterConfig {
  since: number
  powered: boolean
  beian?: string
  custom?: string
}

export interface CommentConfig {
  enable: boolean
  provider?: 'giscus' | 'utterances' | 'disqus'
  repo?: string
  repoId?: string
  category?: string
  categoryId?: string
}

export interface SearchConfig {
  enable: boolean
  placeholder: string
}

export interface BlogConfig {
  site: SiteConfig
  nav: NavItem[]
  social: SocialItem[]
  theme: ThemeConfig
  footer: FooterConfig
  comments: CommentConfig
  search: SearchConfig
  customCss?: string
  customJs?: string
}

let cachedConfig: BlogConfig | null = null

export async function getConfig(): Promise<BlogConfig> {
  if (cachedConfig) return cachedConfig
  const configPath = path.join(process.cwd(), 'content', 'config.yml')
  const file = fs.readFileSync(configPath, 'utf8')
  cachedConfig = yaml.load(file) as BlogConfig
  return cachedConfig
}

export function clearConfigCache() {
  cachedConfig = null
}
