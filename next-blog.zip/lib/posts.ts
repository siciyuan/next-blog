import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import { remark } from 'remark'
import html from 'remark-html'
import remarkGfm from 'remark-gfm'

export interface Post {
  slug: string
  title: string
  date: string
  updated?: string
  tags: string[]
  categories: string[]
  excerpt: string
  content: string
  cover?: string
  readingTime: number
  wordCount: number
  draft: boolean
}

const postsDirectory = path.join(process.cwd(), 'content', 'posts')

function estimateReadingTime(content: string): number {
  const words = content.trim().split(/\s+/).length
  return Math.ceil(words / 200)
}

export async function getAllPosts(): Promise<Post[]> {
  if (!fs.existsSync(postsDirectory)) return []
  const fileNames = fs.readdirSync(postsDirectory)
  const allPosts = await Promise.all(
    fileNames
      .filter((name) => name.endsWith('.md'))
      .map(async (fileName) => {
        const slug = fileName.replace(/\.md$/, '')
        const fullPath = path.join(postsDirectory, fileName)
        const fileContents = fs.readFileSync(fullPath, 'utf8')
        const { data, content } = matter(fileContents)

        const processedContent = await remark()
          .use(remarkGfm)
          .use(html, { allowDangerousHtml: true })
          .process(content)
        const contentHtml = processedContent.toString()

        const plainText = content.replace(/[#*_`\[\]\(\)!]/g, '').trim()
        const excerpt =
          data.excerpt || plainText.slice(0, 200).replace(/\n/g, ' ') + '...'

        return {
          slug,
          title: data.title || slug,
          date: data.date ? new Date(data.date).toISOString() : new Date().toISOString(),
          updated: data.updated ? new Date(data.updated).toISOString() : undefined,
          tags: data.tags || [],
          categories: data.categories || [],
          excerpt,
          content: contentHtml,
          cover: data.cover,
          readingTime: estimateReadingTime(content),
          wordCount: plainText.split(/\s+/).length,
          draft: data.draft || false,
        }
      })
  )

  return allPosts
    .filter((post) => !post.draft)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
}

export async function getPostBySlug(slug: string): Promise<Post | null> {
  const posts = await getAllPosts()
  return posts.find((p) => p.slug === slug) || null
}

export async function getAllTags(): Promise<{ name: string; count: number }[]> {
  const posts = await getAllPosts()
  const tagMap = new Map<string, number>()
  posts.forEach((post) => {
    post.tags.forEach((tag) => {
      tagMap.set(tag, (tagMap.get(tag) || 0) + 1)
    })
  })
  return Array.from(tagMap.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
}

export async function getPostsByTag(tag: string): Promise<Post[]> {
  const posts = await getAllPosts()
  return posts.filter((post) => post.tags.includes(tag))
}

export async function getAllCategories(): Promise<{ name: string; count: number }[]> {
  const posts = await getAllPosts()
  const catMap = new Map<string, number>()
  posts.forEach((post) => {
    post.categories.forEach((cat) => {
      catMap.set(cat, (catMap.get(cat) || 0) + 1)
    })
  })
  return Array.from(catMap.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
}

export async function getPostsByCategory(category: string): Promise<Post[]> {
  const posts = await getAllPosts()
  return posts.filter((post) => post.categories.includes(category))
}

export async function getArchiveData(): Promise<
  { year: string; months: { month: string; posts: Post[] }[] }[]
> {
  const posts = await getAllPosts()
  const archiveMap = new Map<string, Map<string, Post[]>>()

  posts.forEach((post) => {
    const date = new Date(post.date)
    const year = date.getFullYear().toString()
    const month = (date.getMonth() + 1).toString().padStart(2, '0')

    if (!archiveMap.has(year)) archiveMap.set(year, new Map())
    const yearMap = archiveMap.get(year)!
    if (!yearMap.has(month)) yearMap.set(month, [])
    yearMap.get(month)!.push(post)
  })

  return Array.from(archiveMap.entries())
    .sort((a, b) => parseInt(b[0]) - parseInt(a[0]))
    .map(([year, monthsMap]) => ({
      year,
      months: Array.from(monthsMap.entries())
        .sort((a, b) => parseInt(b[0]) - parseInt(a[0]))
        .map(([month, posts]) => ({ month, posts })),
    }))
}

export async function searchPosts(query: string): Promise<Post[]> {
  const posts = await getAllPosts()
  const lowerQuery = query.toLowerCase()
  return posts.filter(
    (post) =>
      post.title.toLowerCase().includes(lowerQuery) ||
      post.excerpt.toLowerCase().includes(lowerQuery) ||
      post.tags.some((t) => t.toLowerCase().includes(lowerQuery))
  )
}
