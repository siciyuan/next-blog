import { getArchiveData } from '@/lib/posts'
import ArchiveTimeline from '@/components/ArchiveTimeline'

export const metadata = { title: '归档' }

export default async function ArchivesPage() {
  const archiveData = await getArchiveData()

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6" style={{ color: 'var(--heading-color)' }}>
        文章归档
      </h1>
      <ArchiveTimeline data={archiveData} />
    </div>
  )
}
