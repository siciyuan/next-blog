import PostList from '@/components/PostList'
import { getAllPosts, getAllTags, getAllCategories } from '@/lib/posts'
import { getConfig } from '@/lib/config'

export default async function Home() {
  const posts = await getAllPosts()
  const tags = await getAllTags()
  const categories = await getAllCategories()
  const config = await getConfig()

  return (
    <div>
      <div className="mb-8 p-6 rounded-xl bg-[var(--secondary-bg)] border border-[var(--border-color)]">
        <h1 className="text-2xl font-bold mb-2" style={{ color: 'var(--heading-color)' }}>
          {config.site.title}
        </h1>
        <p className="text-[var(--muted-color)]">{config.site.subtitle}</p>
        <div className="mt-4 flex flex-wrap gap-4 text-sm text-[var(--muted-color)]">
          <span>文章: {posts.length}</span>
          <span>标签: {tags.length}</span>
          <span>分类: {categories.length}</span>
        </div>
      </div>
      <PostList posts={posts} postsPerPage={config.theme.postsPerPage} />
    </div>
  )
}
