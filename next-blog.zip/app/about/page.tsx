import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import { remark } from 'remark'
import html from 'remark-html'
import remarkGfm from 'remark-gfm'
import MarkdownContent from '@/components/MarkdownContent'
import { getConfig } from '@/lib/config'

export async function generateMetadata() {
  const config = await getConfig()
  return { title: `关于 - ${config.site.title}` }
}

export default async function AboutPage() {
  const aboutPath = path.join(process.cwd(), 'content', 'about.md')
  let contentHtml = '<p>暂无关于页面内容，请在 content/about.md 中编辑。</p>'

  if (fs.existsSync(aboutPath)) {
    const file = fs.readFileSync(aboutPath, 'utf8')
    const { content } = matter(file)
    const processed = await remark().use(remarkGfm).use(html, { allowDangerousHtml: true }).process(content)
    contentHtml = processed.toString()
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6" style={{ color: 'var(--heading-color)' }}>
        关于
      </h1>
      <MarkdownContent content={contentHtml} />
    </div>
  )
}
