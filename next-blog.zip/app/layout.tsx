import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/ThemeProvider'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Sidebar from '@/components/Sidebar'
import { getConfig } from '@/lib/config'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
})

export async function generateMetadata(): Promise<Metadata> {
  const config = await getConfig()
  return {
    title: config.site.title,
    description: config.site.description,
    keywords: config.site.keywords,
    authors: [{ name: config.site.author }],
    openGraph: {
      title: config.site.title,
      description: config.site.description,
      type: 'website',
    },
  }
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const config = await getConfig()
  return (
    <html lang={config.site.language} suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <ThemeProvider>
          <div className='min-h-screen flex flex-col bg-[var(--bg-color)] text-[var(--text-color)]'>
            <Header />
            <div className='flex-1 w-full max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8'>
              <div className='flex flex-col lg:flex-row gap-8'>
                <main className='flex-1 min-w-0'>{children}</main>
                <Sidebar />
              </div>
            </div>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
