import { notFound } from 'next/navigation'
import { getPostBySlug } from '@/lib/posts'
import { getConfig } from '@/lib/config'
import MarkdownContent from '@/components/MarkdownContent'
import Toc from '@/components/Toc'
import BackToTop from '@/components/BackToTop'
import { formatDate } from '@/lib/utils'
import Link from 'next/link'

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const post = await getPostBySlug(params.slug)
  if (!post) return { title: 'Not Found' }
  return { title: post.title, description: post.excerpt }
}

export default async function PostPage({ params }: { params: { slug: string } }) {
  const post = await getPostBySlug(params.slug)
  if (!post) return notFound()

  const config = await getConfig()

  return (
    <article className="relative">
      {post.cover && (
        <div className="mb-6 rounded-xl overflow-hidden">
          <img src={post.cover} alt={post.title} className="w-full h-64 object-cover" />
        </div>
      )}

      <header className="mb-8">
        <h1 className="text-3xl font-bold mb-4" style={{ color: 'var(--heading-color)' }}>
          {post.title}
        </h1>
        <div className="flex flex-wrap gap-4 text-sm text-[var(--muted-color)]">
          <span>发布于 {formatDate(post.date)}</span>
          {post.updated && <span>更新于 {formatDate(post.updated)}</span>}
          <span>{post.readingTime} 分钟阅读</span>
          <span>{post.wordCount} 字</span>
        </div>
        {(post.tags.length > 0 || post.categories.length > 0) && (
          <div className="mt-3 flex flex-wrap gap-2">
            {post.categories.map((cat) => (
              <Link key={cat} href={`/category/${encodeURIComponent(cat)}/`}>
                <span className="px-2 py-1 text-xs rounded bg-[var(--primary-color)] text-white cursor-pointer">
                  {cat}
                </span>
              </Link>
            ))}
            {post.tags.map((tag) => (
              <Link key={tag} href={`/tags/${encodeURIComponent(tag)}/`}>
                <span className="px-2 py-1 text-xs rounded border border-[var(--border-color)] text-[var(--muted-color)] hover:text-[var(--primary-color)] hover:border-[var(--primary-color)] transition-colors">
                  #{tag}
                </span>
              </Link>
            ))}
          </div>
        )}
      </header>

      <div className="flex gap-8">
        <div className="flex-1 min-w-0">
          <MarkdownContent content={post.content} />
        </div>
        {config.theme.showToc && (
          <aside className="hidden xl:block w-64 shrink-0">
            <div className="sticky top-24">
              <Toc content={post.content} />
            </div>
          </aside>
        )}
      </div>

      {config.theme.showBackToTop && <BackToTop />}
    </article>
  )
}
